public class Excepcion extends Exception{
    public Excepcion (String mensaje)
    {
        super(mensaje);
    }
}
