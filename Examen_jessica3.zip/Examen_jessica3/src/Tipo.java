public enum Tipo {
    mtb,carretera,paseo;


}
